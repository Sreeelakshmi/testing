---
title: Build multipage apps
slug: /develop/tutorials/multipage
---

# Build multipage apps

<TileContainer layout="list">

<RefCard href="/develop/tutorials/multipage/st.page_link-nav">

<h5>Build a custom navigation menu with `st.page_link`</h5>

Create a dynamic, user-dependant navigation menu to replace the default sidebar navigation.

</RefCard>

</TileContainer>
