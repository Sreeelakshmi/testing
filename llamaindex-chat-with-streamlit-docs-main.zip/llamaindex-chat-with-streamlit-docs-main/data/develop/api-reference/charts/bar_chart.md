---
title: st.bar_chart
slug: /develop/api-reference/charts/st.bar_chart
description: st.bar_chart displays a bar chart.
---

<Autofunction function="streamlit.bar_chart" />

<Autofunction function="DeltaGenerator.add_rows" />
