---
title: st.pyplot
slug: /develop/api-reference/charts/st.pyplot
description: st.pyplot displays a matplotlib.pyplot figure.
---

<Autofunction function="streamlit.pyplot" />
