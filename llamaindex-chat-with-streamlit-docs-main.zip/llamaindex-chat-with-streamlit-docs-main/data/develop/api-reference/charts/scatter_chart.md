---
title: st.scatter_chart
slug: /develop/api-reference/charts/st.scatter_chart
description: st.scatter_chart displays an scatter chart.
---

<Autofunction function="streamlit.scatter_chart" />

<Autofunction function="DeltaGenerator.add_rows" />
