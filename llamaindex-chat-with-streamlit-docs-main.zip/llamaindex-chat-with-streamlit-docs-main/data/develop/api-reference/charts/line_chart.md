---
title: st.line_chart
slug: /develop/api-reference/charts/st.line_chart
description: st.line_chart displays a line chart.
---

<Autofunction function="streamlit.line_chart" />

<Autofunction function="DeltaGenerator.add_rows" />
