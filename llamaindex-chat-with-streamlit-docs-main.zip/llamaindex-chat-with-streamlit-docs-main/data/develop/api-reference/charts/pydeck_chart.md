---
title: st.pydeck_chart
slug: /develop/api-reference/charts/st.pydeck_chart
description: st.pydeck_chart displays a chart using the PyDeck library.
---

<Autofunction function="streamlit.pydeck_chart" />
