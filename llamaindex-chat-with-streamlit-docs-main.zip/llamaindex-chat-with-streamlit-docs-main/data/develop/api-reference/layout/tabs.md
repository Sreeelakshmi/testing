---
title: st.tabs
slug: /develop/api-reference/layout/st.tabs
description: st.tabs inserts containers separated into tabs.
---

<Autofunction function="streamlit.tabs" />
