---
title: st.expander
slug: /develop/api-reference/layout/st.expander
description: st.expander inserts a multi-element container that can be expanded/collapsed.
---

<Autofunction function="streamlit.expander" />
