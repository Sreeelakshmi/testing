---
title: st.columns
slug: /develop/api-reference/layout/st.columns
description: st.columns inserts containers laid out as side-by-side columns.
---

<Autofunction function="streamlit.columns" />
