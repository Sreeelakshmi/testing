---
title: st.column_config.NumberColumn
slug: /develop/api-reference/data/st.column_config/st.column_config.numbercolumn
---

<Autofunction function="streamlit.column_config.NumberColumn" />
