---
title: st.column_config.ImageColumn
slug: /develop/api-reference/data/st.column_config/st.column_config.imagecolumn
---

<Autofunction function="streamlit.column_config.ImageColumn" />
