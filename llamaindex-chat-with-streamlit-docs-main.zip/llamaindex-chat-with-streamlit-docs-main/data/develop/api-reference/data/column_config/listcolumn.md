---
title: st.column_config.ListColumn
slug: /develop/api-reference/data/st.column_config/st.column_config.listcolumn
---

<Autofunction function="streamlit.column_config.ListColumn" />
