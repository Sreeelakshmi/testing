---
title: st.column_config.TimeColumn
slug: /develop/api-reference/data/st.column_config/st.column_config.timecolumn
---

<Autofunction function="streamlit.column_config.TimeColumn" />
