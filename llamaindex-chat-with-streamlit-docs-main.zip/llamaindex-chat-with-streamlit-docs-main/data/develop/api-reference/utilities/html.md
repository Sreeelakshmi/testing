---
title: st.html
slug: /develop/api-reference/utilities/st.html
description: st.html renders arbitrary HTML strings to your app
---

<Autofunction function="streamlit.html" />
