---
title: st.exception
slug: /develop/api-reference/status/st.exception
description: st.exception displays an exception.
---

<Autofunction function="streamlit.exception" />
