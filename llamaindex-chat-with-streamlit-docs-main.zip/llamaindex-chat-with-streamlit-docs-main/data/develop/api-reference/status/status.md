---
title: st.status
slug: /develop/api-reference/status/st.status
description: st.status inserts a mutable expander element
---

<Autofunction function="streamlit.status" />

<Autofunction function="StatusContainer.update" />
