---
title: st.snow
slug: /develop/api-reference/status/st.snow
description: st.snow displays celebratory snowflakes!
---

<Autofunction function="streamlit.snow" />
