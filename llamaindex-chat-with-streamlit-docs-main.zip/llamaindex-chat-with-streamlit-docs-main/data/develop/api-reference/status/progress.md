---
title: st.progress
slug: /develop/api-reference/status/st.progress
description: st.progress displays a progress bar.
---

<Autofunction function="streamlit.progress" />
