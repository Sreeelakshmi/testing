---
title: st.info
slug: /develop/api-reference/status/st.info
description: st.info displays an informational message.
---

<Autofunction function="streamlit.info" />
