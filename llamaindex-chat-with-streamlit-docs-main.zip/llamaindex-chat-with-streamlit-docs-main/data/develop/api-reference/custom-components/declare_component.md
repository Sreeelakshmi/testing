---
title: st.components.v1.declare_component
slug: /develop/api-reference/custom-components/st.components.v1.declare_component
---

<Autofunction function="streamlit.components.v1.declare_component" />
