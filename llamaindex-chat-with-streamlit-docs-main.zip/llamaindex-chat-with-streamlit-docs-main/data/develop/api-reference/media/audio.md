---
title: st.audio
slug: /develop/api-reference/media/st.audio
description: st.audio displays an audio player.
---

<Autofunction function="streamlit.audio" />
