---
title: st.fragment
slug: /develop/api-reference/execution-flow/st.fragment
description: st.fragment is a decorator that allows a function to rerun independently
---

<Autofunction function="streamlit.experimental_fragment" />
