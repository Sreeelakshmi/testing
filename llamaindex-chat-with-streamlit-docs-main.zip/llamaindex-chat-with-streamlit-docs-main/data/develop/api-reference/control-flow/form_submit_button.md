---
title: st.form_submit_button
slug: /develop/api-reference/execution-flow/st.form_submit_button
description: st.form_submit_button displays a form submit button.
---

<Autofunction function="streamlit.form_submit_button" />
