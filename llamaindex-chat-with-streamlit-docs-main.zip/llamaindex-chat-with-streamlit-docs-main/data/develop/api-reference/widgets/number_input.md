---
title: st.number_input
slug: /develop/api-reference/widgets/st.number_input
description: st.number_input displays a numeric input widget.
---

<Autofunction function="streamlit.number_input" />
