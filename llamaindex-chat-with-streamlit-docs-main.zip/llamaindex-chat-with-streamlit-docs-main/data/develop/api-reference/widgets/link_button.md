---
title: st.link_button
slug: /develop/api-reference/widgets/st.link_button
---

<Autofunction function="streamlit.link_button" />
