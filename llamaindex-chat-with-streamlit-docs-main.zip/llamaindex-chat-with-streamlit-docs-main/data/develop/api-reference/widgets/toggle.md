---
title: st.toggle
slug: /develop/api-reference/widgets/st.toggle
description: st.toggle displays a toggle widget.
---

<Autofunction function="streamlit.toggle" />
