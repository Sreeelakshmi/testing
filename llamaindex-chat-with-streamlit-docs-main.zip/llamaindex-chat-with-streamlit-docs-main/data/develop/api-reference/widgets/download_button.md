---
title: st.download_button
slug: /develop/api-reference/widgets/st.download_button
description: st.download_button displays a download button widget.
---

<Autofunction function="streamlit.download_button" />
