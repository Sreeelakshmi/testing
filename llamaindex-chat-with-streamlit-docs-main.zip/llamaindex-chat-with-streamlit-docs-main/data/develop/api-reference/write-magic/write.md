---
title: st.write
slug: /develop/api-reference/write-magic/st.write
description: st.write writes arguments to the app.
---

<Autofunction function="streamlit.write" />

### Featured video

Learn what the [`st.write`](/develop/api-reference/write-magic/st.write) and [magic](/develop/api-reference/write-magic/magic) commands are and how to use them.

<YouTube videoId="wpDuY9I2fDg" />
