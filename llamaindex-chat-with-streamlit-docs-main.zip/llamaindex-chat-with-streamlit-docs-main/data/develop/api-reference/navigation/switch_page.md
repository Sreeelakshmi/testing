---
title: st.switch_page
slug: /develop/api-reference/navigation/st.switch_page
description: st.switch_page programmatically switches the active page.
---

<Autofunction function="streamlit.switch_page" />
