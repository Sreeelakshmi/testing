---
title: st.subheader
slug: /develop/api-reference/text/st.subheader
description: st.subheader displays text in subheader formatting.
---

<Autofunction function="streamlit.subheader" />
