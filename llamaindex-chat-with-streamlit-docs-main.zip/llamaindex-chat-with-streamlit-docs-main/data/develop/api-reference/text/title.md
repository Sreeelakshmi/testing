---
title: st.title
slug: /develop/api-reference/text/st.title
description: st.title displays text in title formatting.
---

<Autofunction function="streamlit.title" />
