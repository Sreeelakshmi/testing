---
title: st.header
slug: /develop/api-reference/text/st.header
description: st.header displays text in header formatting.
---

<Autofunction function="streamlit.header" />
